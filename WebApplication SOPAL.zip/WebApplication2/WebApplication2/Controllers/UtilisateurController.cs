﻿using Microsoft.AspNetCore.Mvc;
using WebApplication2.Models;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using WebApplication2.Data;

namespace WebApplication2.Controllers
{
    public class UtilisateurController : Controller
    {
        private readonly AppDbContext _context;

        public UtilisateurController(AppDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IActionResult Create()
        {
            var user = new Utilisateur { IsNew = true }; 
            return View(user);
        }

        [HttpPost]
        public async Task<IActionResult> Create(Utilisateur user)
        {
            if (ModelState.IsValid)
            {
                _context.Add(user);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }

        public IActionResult Edit(int id)
        {
            var utilisateur = _context.TableFINALEFINALE.Find(id);
            if (utilisateur == null)
            {
                return NotFound();
            }
            utilisateur.IsNew = false; 
            return View(utilisateur);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, Utilisateur utilisateur)
        {
            if (id != utilisateur.Référence)
            {
                return NotFound();
            }

            utilisateur.IsNew = false; 

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(utilisateur);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!UserExists(utilisateur.Référence))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(utilisateur);
        }

        private bool UserExists(int id)
        {
            return _context.TableFINALEFINALE.Any(e => e.Référence == id);
        }

        public IActionResult Index()
        {
            var utilisateurs = _context.TableFINALEFINALE.ToList();
            return View(utilisateurs);
        }

        public IActionResult Delete(int id)
        {
            var utilisateur = _context.TableFINALEFINALE.Find(id);
            if (utilisateur != null)
            {
                _context.TableFINALEFINALE.Remove(utilisateur);
                _context.SaveChanges();
            }
            return RedirectToAction("Index");
        }

        public IActionResult Details(int id)
        {
            var utilisateur = _context.TableFINALEFINALE.Find(id);
            if (utilisateur == null)
            {
                return NotFound();
            }
            return View(utilisateur);
        }

        [AcceptVerbs("Get", "Post")]
        public IActionResult VerifyReference(int référence)
        {
            if (_context.TableFINALEFINALE.Any(u => u.Référence == référence))
            {
                return Json($"La référence {référence} est déjà utilisée.");
            }
            return Json(true);
        }
    }
}


