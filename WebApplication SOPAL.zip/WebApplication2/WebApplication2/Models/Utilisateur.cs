﻿// Models/Utilisateur.cs
using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Mvc;
using WebApplication2.Data;
using WebApplication2.Controllers;

namespace WebApplication2.Models
{
    [Table("TableFINALEFINALE")]
    public class Utilisateur
    {
        [Key]
        [Required]
        [CustomReferenceValidation(ErrorMessage = "Cette référence existe déjà.")]
        public int Référence { get; set; }

        [Required]
        public int? CodeBarre { get; set; }

        [Required]
        public string Emplacement { get; set; }

        [Required]
        public DateOnly? DateDeMiseEnService { get; set; }

        [Required]
        public DateOnly? DateDuDernierEtalonnage { get; set; }

        [Required]
        public DateOnly? DateDeCreation { get; set; }

        public DateOnly? DateMiseAJour { get; set; }

        [Required]
        public int? PeriodiciteEtalonnage { get; set; }

        [Required]
        public int? DernierPoids { get; set; }

        [Required]
        public int? Unite { get; set; }

        [Required]
        public string UserCreate { get; set; }

        [Required]
        public string UserUpdate { get; set; }

        [Required]
        public DateOnly? Date { get; set; }

        [NotMapped]
        public bool IsNew { get; set; } = true;
    }

    public class CustomReferenceValidationAttribute : ValidationAttribute
    {
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var dbContext = (AppDbContext)validationContext.GetService(typeof(AppDbContext));
            var référence = (int)value;

            var utilisateur = (Utilisateur)validationContext.ObjectInstance;

            if (utilisateur.IsNew && dbContext.TableFINALEFINALE.Any(t => t.Référence == référence))
            {
                return new ValidationResult(ErrorMessage);
            }

            return ValidationResult.Success;
        }
    }
}

