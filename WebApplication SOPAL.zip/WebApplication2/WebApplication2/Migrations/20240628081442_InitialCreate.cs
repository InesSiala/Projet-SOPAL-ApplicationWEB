﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApplication2.Migrations
{
    /// <inheritdoc />
    public partial class InitialCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "TableFINALEFINALE",
                columns: table => new
                {
                    Référence = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    CodeBarre = table.Column<int>(type: "int", nullable: false),
                    Emplacement = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DateDeMiseEnService = table.Column<DateOnly>(type: "date", nullable: false),
                    DateDuDernierEtaonnage = table.Column<DateOnly>(type: "date", nullable: true),
                    DateDeCreation = table.Column<DateOnly>(type: "date", nullable: false),
                    DateMiseAJour = table.Column<DateOnly>(type: "date", nullable: true),
                    PeriodiciteEtalonnage = table.Column<int>(type: "int", nullable: false),
                    DerinerPoids = table.Column<int>(type: "int", nullable: false),
                    Unite = table.Column<int>(type: "int", nullable: false),
                    UserCreate = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    UserUpdate = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Date = table.Column<DateOnly>(type: "date", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TableFINALEFINALE", x => x.Référence);
                });
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "TableFINALEFINALE");
        }
    }
}
